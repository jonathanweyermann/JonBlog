require 'test_helper'

class Admin::SessionsHelperTest < ActionView::TestCase
end
