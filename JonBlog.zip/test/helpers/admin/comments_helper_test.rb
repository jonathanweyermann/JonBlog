require 'test_helper'

class Admin::CommentsHelperTest < ActionView::TestCase
end
