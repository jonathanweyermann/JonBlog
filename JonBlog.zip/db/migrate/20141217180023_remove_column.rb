class RemoveColumn < ActiveRecord::Migration
  def change
  end
end
